# Metodos_Financiamento_Atuariais_R
Código, na linguagem R, dos métodos de financiamento atuariais: Crédito Unitário Projetado (CUP) e Idade de Entrada Normal (IEN).
