# ALM - Algoritmos Genéticos - Cálculo Atuarial
TCC de Eduardo - Otimização, por meio de Algoritmos Genéticos, de Portfólio com o objetivo de minimizar a Probabilidade de Ruína a partir de um ALM aplicado a um RPPS da Paraíba.
Utiliza a metodologia de Amaral (2010) como referência para implementar o ALM e os algoritmos genéticos. 

Amaral, F. V. A. (2010). GESTÃO DE ATIVOS E PASSIVOS EM ENTIDADES FECHADAS DE PREVIDÊNCIA COMPLEMENTAR. Dissertação de Mestrado em Administração. UFMG. Belo Horizonte. 
